# Example Python Code to Insert a Document 

from pymongo import MongoClient
from pymongo.errors import PyMongoError

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username, password):
        # Connection Variables
        USER = username
        PASS = password
        HOST = 'localhost'
        PORT = 27017
        DB = 'aac'
        COL = 'animals'

        # Initialize Connection
        try:
            self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
            self.database = self.client[DB]
            self.collection = self.database[COL]
        except PyMongoError as e:
            print(f"Connection Error: {e}")

    # CREATE (C in CRUD)
    def create(self, data):
        """Insert a document into MongoDB"""
        try:
            if data is not None:
                self.collection.insert_one(data)
                return True
            else:
                return False
        except PyMongoError as e:
            print(f"Create Error: {e}")
            return False

    # READ (R in CRUD)
    def read(self, query):
        """Query documents from MongoDB"""
        try:
            results = self.collection.find(query)
            return list(results)  # must return list
        except PyMongoError as e:
            print(f"Read Error: {e}")
            return []

    # UPDATE (U in CRUD)
    def update(self, query, new_values):
        """Update document(s) in MongoDB"""
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except PyMongoError as e:
            print(f"Update Error: {e}")
            return 0

    # DELETE (D in CRUD)
    def delete(self, query):
        """Delete document(s) from MongoDB"""
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"Delete Error: {e}")
            return 0